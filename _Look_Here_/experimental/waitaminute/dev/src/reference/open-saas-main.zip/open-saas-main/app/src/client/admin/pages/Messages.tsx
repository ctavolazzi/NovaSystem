// TODO: Add messages page

function AdminMessages() {

  return (
    <div>Hello world!</div>
  )
}

export default AdminMessages
