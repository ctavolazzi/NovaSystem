def reverse(data: str) -> str:
    return data[::-1]