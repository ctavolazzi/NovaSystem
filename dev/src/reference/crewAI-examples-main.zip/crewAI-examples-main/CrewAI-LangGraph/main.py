from src.graph import WorkFlow

app = WorkFlow().app
app.invoke({})